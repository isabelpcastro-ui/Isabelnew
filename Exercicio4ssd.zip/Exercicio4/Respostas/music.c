
#include "music.h"
#include <stdio.h>
#include <stdlib.h>


struct Music
{
    char *titulo;
    char *artista;
    int qtd_participantes;
    char **participantes;
    char *album;
    char *genero;
};


/**
 * @brief Lê os dados de uma música da entrada padrão e constrói a estrutura correspondente.
 * A ordem de leitura esperada é: Título, Artista, Quantidade de Feats, Lista com os nomes dos Feats, Álbum e Gênero.
 * @return Ponteiro para a estrutura Music recém-criada.
 */
Music *music_read_and_construct()
{
    Music *m = (Music *)malloc(sizeof(Music));

    m->qtd_participantes = 1;

    m->titulo = (char *)malloc(sizeof(char) * MAX_TAM_STRING);
    m->artista = (char *)malloc(sizeof(char) * MAX_TAM_STRING);
    m->participantes = (char **)malloc(sizeof(char));
    m->album = (char *)malloc(sizeof(char) * MAX_TAM_STRING);
    m->genero = (char *)malloc(sizeof(char) * MAX_TAM_STRING);

    scanf("%[^\n]\n" ,m->titulo);
    scanf("%[^\n]\n" ,m->artista);

    scanf("%d\n" ,m->qtd_participantes);
    m->participantes = (char *)realloc(m->participantes, sizeof(char) * m->qtd_participantes);
    
    for (int i = 0; i < m->qtd_participantes; i++)
    {
        scanf("%[\n]\n" ,m->participantes[i]);
    }

    scanf("%[^\n]\n" ,m->album);
    scanf("%[^\n]\n" ,m->genero);

    return m;
}

/**
 * @brief Imprime os dados formatados de uma música.
 * A formatação exibirá, linha por linha: o Nome, o Artista, os Feats (se a quantidade for maior que zero), o Álbum e o Gênero.
 * @param m Ponteiro genérico que aponta para a estrutura Music.
 */
void music_print(void *m)
{
    Music *musica = (Music *)m;

    printf("%s\n" ,musica->titulo);
    printf("%s\n" ,musica->artista);

    if (musica->qtd_participantes > 0)
        for (int i = 0; i < musica->qtd_participantes; i++)
                printf("%s\n" ,musica->participantes[i]);

    printf("%s\n" ,musica->album);
    printf("%s\n" ,musica->genero);
}

/**
 * @brief Libera a memória alocada para a estrutura de uma música.
 * @param m Ponteiro genérico que aponta para a estrutura Music.
 */
void music_free(void *m)
{
    Music *musica = (Music *)m;

    free(musica->album);
    free(musica->artista);
    free(musica->genero);
    free(musica->titulo);

    for (int  i = 0; i < musica->qtd_participantes; i++)
    {
        free(musica->participantes[i]);

    }
    free(musica->participantes);
    
    free(musica);
}
