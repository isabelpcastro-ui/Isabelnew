#include <stdio.h>
#include "lesao.h"
#include <stdlib.h>
#include <string.h>

struct Lesao{
    char *cartaoSus;
    char *idLesao;
    char *diagnostico;
    char *regiaoCorpo;
    int malignidade;
};
tLesao *leLesao()
{
    
}
void printLesao(tLesao **les, int qtdLesoes)
{
    
}
void obtemCartaoSusLesao(tLesao *les, char cartaoSus[])
{

}
int chanceCirirgiaLesao(tLesao *les);
void liberaLesao(tLesao *les);