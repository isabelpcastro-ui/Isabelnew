#include <stdio.h>
#include <stdlib.h>
#include "data.h"

struct Data
{
    int ano;
    int mes;
    int dia;
};

tData* leData()
{
    tData *d = (tData *) malloc (sizeof(tData));

    scanf("%d/%d/%d\n" ,&d->dia ,&d->mes ,&d->ano);

    return d;
}
void printData(tData* d)
{
    printf("%d/%d/%d" ,d->ano ,d->mes ,d->dia);
}
int retornaAno(tData* inicio)
{
    tData data;
    int idade;

    data.ano = 2024;
    data.mes = 3;
    data.dia = 4;
    
    idade = data.ano - inicio->ano;

    if (data.mes < inicio->mes)
        idade--;
    if (data.mes == inicio->mes)
        if (data.dia < inicio->dia)
            idade--;

    return idade;
}
void liberaData(tData *d)
{
    free(d);
}
